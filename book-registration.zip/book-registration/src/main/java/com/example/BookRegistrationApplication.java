package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookRegistrationApplication.class, args);
	}
}
